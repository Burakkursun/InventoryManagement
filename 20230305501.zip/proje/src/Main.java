import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Envanter nesnesi oluşturuluyor
        Inventory inventory = new Inventory();

        // Başlangıçta örnek ürünler ekleniyor poli
        Product laptop = new ElectronicProduct("P001", "Laptop", 1000.0, 10, "Dell");
        Product smartphone = new ElectronicProduct("P002", "Smartphone", 500.0, 20, "Samsung");
        Product tablet = new ElectronicProduct("P003", "Tablet", 300.0, 15, "Apple");

        inventory.addProduct(laptop);
        inventory.addProduct(smartphone);
        inventory.addProduct(tablet);

        // Scanner nesnesi ile kullanıcıdan giriş almak için
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        // Ana menü
        while (!exit) {
            System.out.println("=== Envanter Yönetim Sistemi ===");
            System.out.println("1. Ürün Ekle");
            System.out.println("2. Ürün Sil");
            System.out.println("3. Envanteri Görüntüle");
            System.out.println("4. Fiyatları %10 Artır");
            System.out.println("5. Adı 'Laptop' Olan Ürünleri Listele");
            System.out.println("6. Temizle");
            System.out.println("7. Çıkış");
            System.out.print("Seçiminizi yapın: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Temizleme (nextInt sonrası nextLine kullanmak için)

            switch (choice) {
                case 1:
                    // Ürün eklemek
                    System.out.print("Ürün Adı: ");
                    String name = scanner.nextLine();
                    System.out.print("Ürün ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Ürün Fiyatı: ");
                    double price = scanner.nextDouble();
                    System.out.print("Ürün Miktarı: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine(); // Temizleme

                    // Yeni ürün oluşturuluyor ve envantere ekleniyor
                    Product product = new ElectronicProduct(id, name, price, quantity, "Unknown");
                    inventory.addProduct(product);
                    break;

                case 2:
                    // Ürün silmek
                    System.out.print("Silmek istediğiniz ürün ID'si: ");
                    String productId = scanner.nextLine();
                    inventory.removeProduct(productId);
                    break;

                case 3:
                    // Envanteri görüntülemek
                    System.out.println("Envanteriniz:");
                    inventory.displayInventory();
                    break;

                case 4:
                    // Fiyatları %10 artırmak
                    inventory.increasePriceOfAllProducts();
                    System.out.println("Fiyatlar %10 artırıldı.");
                    break;

                case 5:
                    // Adı "Laptop" olan ürünleri listelemek
                    System.out.println("Laptop ürünleri:");
                    inventory.displayLaptopProducts();
                    break;
                case 6:
                    inventory.clearAllProduct();
                    System.out.println("Tüm ürünler başarıyla silindi.");
                    break;
                case 7:
                    // Çıkış
                    exit = true;
                    System.out.println("Çıkılıyor...");
                    break;

                default:
                    System.out.println("Geçersiz seçim! Lütfen tekrar deneyin.");
            }
        }

        scanner.close();
    }
}
