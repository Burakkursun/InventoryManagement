import java.util.Map;
import java.util.HashMap;

public class Inventory implements InventoryOperations//InventoryOperations interfaceini implement eder
{
    private Map<String, Product> products = new HashMap<>();

    @Override
    public void addProduct(Product product) {
        products.put(product.getId(), product);
    }

    @Override
    public void removeProduct(String productId) {
        products.remove(productId);
    }
    public void clearAllProduct(){
        products.clear();
}

    @Override
    public void displayInventory() {
        // Lambda ile tüm ürünleri listeleme
        products.values().forEach(product -> product.displayProduct());
    }

    // Lambda ile fiyatı %10 artırma
    public void increasePriceOfAllProducts() {
        products.values().forEach(product -> {
            double newPrice = product.getPrice() * 1.1;
            product.setPrice(newPrice);
            System.out.println("New price of " + product.getName() + ": " + newPrice);
        });
    }

    // Lambda ile "Laptop" ürünlerini filtreleme
    public void displayLaptopProducts() {
        products.values().stream()
                .filter(product -> product.getName().equals("Laptop"))
                .forEach(product -> product.displayProduct());
    }
}
