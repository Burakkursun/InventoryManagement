public interface InventoryOperations {
    void addProduct(Product product);
    void removeProduct(String productId);
    void displayInventory();
    void clearAllProduct();
}
