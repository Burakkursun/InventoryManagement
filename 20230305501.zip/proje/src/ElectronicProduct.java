public class ElectronicProduct extends Product {//kalıtım kısmı product ın içindeki heşeyi electronic product a bağlar
    private String brand;//değişkenim

    public ElectronicProduct(String id, String name, double price, int quantity, String brand) {
        super(id, name, price, quantity);//kalıtımı çektiğimiz kısım
        this.brand = brand;//paremetreli fonk. bu parametrelerden oluşan fonk.
    }

    @Override//alt sınıftan üst sınıfı tanımlıyor
    public void displayProduct() {
        System.out.println("ID: " + getId() + ", Name: " + getName() + ", Price: " + getPrice() + ", Quantity: " + getQuantity() + ", Brand: " + brand);
    }

    // Getter ve Setter metodları
    public String getBrand() { return brand; }
}
